| Component                  | Copyright                                             | License             |
|:---------                  |:----------                                            |:-------             |
| Cortex-M CMSIS             | ARM Limited                                           | Apache License 2.0  |
| STM32H5xx CMSIS            | ARM Limited - STMicroelectronics                      | Apache License 2.0  |
| STM32H5xx HAL              | STMicroelectronics                                    | BSD 3-Clause        |
| BSP STM32H5xx NUCLEO       | STMicroelectronics                                    | BSD 3-Clause        |
| BSP Components             | STMicroelectronics                                    | BSD 3-Clause        |
| FatFS                      | ChaN - STMicroelectronics                             | BSD-3-Clause        |
| LwIP                       | Swedish Institute of Computer Science	             | BSD-3-Clause        |
| STM32_USB_Device_Library   | STMicroelectronics                                    | SLA0044             |
| STM32_USB_Host_Library     | STMicroelectronics                                    | SLA0044             |
| STM32 USBPD Core Library   | STMicroelectronics                                    | SLA0044             |
| STM32 USBPD Device Library | STMicroelectronics                                    | SLA0044             |
| Applications projects      | STMicroelectronics                                    | SLA0044             |
